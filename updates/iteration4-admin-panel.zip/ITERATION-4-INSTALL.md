# 🚀 Iteration 4: Admin Panel — Инструкция установки

## 📍 Что это

**Admin Panel** — веб-приложение для управления License Server.
React SPA с тёмной темой, работает в браузере на порту **3002**.

---

## 📁 Структура

```
packages/admin/
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
├── .env                          ← URL License Server
├── public/
│   └── favicon.svg
└── src/
    ├── main.tsx
    ├── App.tsx                   ← Router + auth guard
    ├── stores/
    │   └── authStore.ts          ← Zustand: login/logout/token
    ├── services/
    │   └── adminApi.ts           ← Typed HTTP client для всех 16 endpoints
    ├── styles/
    │   └── global.css            ← Dark theme base
    ├── components/
    │   ├── Layout.tsx/.css       ← Sidebar + header
    │   ├── StatCard.tsx/.css     ← Метрика (title / value / subtitle)
    │   ├── PlanChart.tsx/.css    ← Горизонтальный бар-чарт
    │   ├── ActivityFeed.tsx/.css ← Timeline последних событий
    │   ├── Badge.tsx/.css        ← Цветные бейдже
    │   └── CreateLicenseModal.tsx/.css ← Модальное окно создания лицензии
    └── pages/
        ├── Login.tsx/.css        ← Авторизация
        ├── Dashboard.tsx/.css    ← Главная: карточки + чарты + feed
        ├── Licenses.tsx/.css     ← CRUD лицензий
        ├── Devices.tsx/.css      ← Список устройств
        └── AuditLogs.tsx/.css    ← Пагинированные логи
```

---

## ⚡ Установка

### 1. Копируйте папку `packages/admin` в монорепо

```bash
cp -r packages/admin /opt/kiosk/kiosk-content-platform/packages/admin
cd /opt/kiosk/kiosk-content-platform/packages/admin
```

### 2. Установите зависимости

```bash
npm install
```

### 3. Запустите dev-сервер

```bash
npm run dev
# Откроется http://localhost:3002
```

### 4. Войдите

```
Email:    admin@kiosk.local
Password: Admin123!
```

---

## 🏗️ Prod-сборка

```bash
npm run build
# Output → dist/
# Раздавать через nginx или любой静态-сервер
```

---

## ⚙️ Переменные окружения

| Переменная | Значение по умолчанию | Описание |
|---|---|---|
| `VITE_LICENSE_SERVER_URL` | `http://194.58.92.190:3001` | URL License Server |

Для локального тестирования замените на `http://localhost:3001`.

---

## 📡 API-интеграция

Admin Panel обращается ко всем endpoint License Server:

| Метод | Путь | Использование |
|---|---|---|
| POST | `/api/admin/login` | Авторизация → JWT |
| GET | `/api/admin/stats` | Dashboard карточки |
| GET | `/api/admin/licenses` | Список лицензий |
| POST | `/api/admin/licenses` | Создание лицензии |
| GET | `/api/admin/licenses/:id` | Детали лицензии |
| PATCH | `/api/admin/licenses/:id` | Обновление статуса |
| GET | `/api/admin/devices` | Список устройств |
| DELETE | `/api/admin/devices/:id` | Деактивация устройства |
| GET | `/api/admin/audit` | Audit logs |

---

## 🎨 Дизайн-система

| Элемент | Значение |
|---|---|
| BG base | `#0f1117` |
| BG surface | `#161822` |
| BG elevated | `#1e2130` |
| Text primary | `#e2e4e9` |
| Text secondary | `#8b8fa3` |
| Border | `#2a2d3a` |
| Blue accent | `#3b82f6` |
| Green accent | `#22c55e` |
| Purple accent | `#8b5cf6` |
| Orange accent | `#f59e0b` |
| Red accent | `#ef4444` |

---

## 📊 Что показывает Dashboard

- **4 карточки:** Всего лицензий / Всего устройств / Editor устройств / Player устройств
- **2 чарта:** Распределение по плану (BASIC/PRO/MAX) и по статусу (ACTIVE/SUSPENDED/EXPIRED/CANCELLED)
- **Activity Feed:** Последние 10 событий из audit logs

---

## ✅ Checklist после установки

- [ ] `npm run dev` запускается без ошибок
- [ ] Страница `/login` открывается
- [ ] Вход по `admin@kiosk.local` / `Admin123!` работает
- [ ] Dashboard показывает данные из сервера
- [ ] Лицензии, устройства, логи загружаются
- [ ] Создание лицензии через модальное окно работает

---

## 🗺️ Что дальше (Iteration 5)

- Страница детальный просмотр лицензии с привязанными устройствами
- Real-time обновления через WebSocket / polling
- Экспорт данных в CSV
- Управление пользователями-администраторами
