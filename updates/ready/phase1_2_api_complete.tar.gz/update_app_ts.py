#!/usr/bin/env python3
"""
Скрипт для автоматического обновления app.ts
Добавляет Client API routes в License Server
"""

import re
import sys
from datetime import datetime
from pathlib import Path

# Цвета для вывода
class Colors:
    BLUE = '\033[0;34m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    RED = '\033[0;31m'
    NC = '\033[0m'

def print_header(text):
    print(f"{Colors.BLUE}{'=' * 70}{Colors.NC}")
    print(f"{Colors.BLUE}{text}{Colors.NC}")
    print(f"{Colors.BLUE}{'=' * 70}{Colors.NC}\n")

def print_success(text):
    print(f"{Colors.GREEN}✓{Colors.NC} {text}")

def print_error(text):
    print(f"{Colors.RED}✗{Colors.NC} {text}")

def print_warning(text):
    print(f"{Colors.YELLOW}⚠{Colors.NC} {text}")

def update_app_ts():
    print_header("Обновление app.ts - добавление Client API Routes")
    
    app_file = Path("/opt/kiosk/kiosk-content-platform/packages/server/src/app.ts")
    
    # Проверка что файл существует
    if not app_file.exists():
        print_error(f"Файл не найден: {app_file}")
        return False
    
    print(f"{Colors.BLUE}[1]{Colors.NC} Чтение app.ts...")
    content = app_file.read_text()
    
    # Проверка что роуты ещё не добавлены
    if "authRoutes" in content:
        print_warning("Client API routes уже добавлены")
        print_warning("app.ts уже содержит authRoutes")
        response = input(f"\n{Colors.YELLOW}Продолжить? (y/n): {Colors.NC}")
        if response.lower() != 'y':
            print("Отменено пользователем")
            return False
    
    print(f"\n{Colors.BLUE}[2]{Colors.NC} Создание backup...")
    backup_file = app_file.with_suffix(f".ts.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    backup_file.write_text(content)
    print_success(f"Backup: {backup_file}")
    
    print(f"\n{Colors.BLUE}[3]{Colors.NC} Модификация app.ts...")
    
    # Разбиваем на строки для удобства
    lines = content.split('\n')
    new_lines = []
    
    imports_added = False
    body_parser_updated = False
    routes_added = False
    
    i = 0
    while i < len(lines):
        line = lines[i]
        new_lines.append(line)
        
        # 1. Добавляем импорты после adminRoutes
        if "import adminRoutes from" in line and not imports_added:
            new_lines.append("")
            new_lines.append("// Client API routes")
            new_lines.append("import authRoutes from './routes/auth.routes';")
            new_lines.append("import projectRoutes from './routes/project.routes';")
            imports_added = True
            print_success("  Добавлены импорты Client API routes")
        
        # 2. Обновляем body parser (если ещё не обновлён)
        if "app.use(express.json())" in line and not body_parser_updated and "limit" not in line:
            # Удаляем последнюю добавленную строку
            new_lines.pop()
            new_lines.append("// Enable larger body size for file uploads")
            new_lines.append("app.use(express.json({ limit: '10mb' }));")
            new_lines.append("app.use(express.urlencoded({ extended: true, limit: '10mb' }));")
            body_parser_updated = True
            print_success("  Обновлены настройки body parser (10mb limit)")
        
        # 3. Добавляем роуты после /api/admin
        if "app.use('/api/admin'" in line and not routes_added:
            new_lines.append("")
            new_lines.append("// Client API endpoints")
            new_lines.append("app.use('/api/auth', authRoutes);")
            new_lines.append("app.use('/api/projects', projectRoutes);")
            new_lines.append("")
            new_lines.append("// Storage stats endpoint (requires authentication)")
            new_lines.append("app.get('/api/storage/stats', async (req, res) => {")
            new_lines.append("  const { FileController } = await import('./controllers/FileController');")
            new_lines.append("  return FileController.getStorageStats(req, res);")
            new_lines.append("});")
            routes_added = True
            print_success("  Добавлены Client API routes")
        
        i += 1
    
    # Объединяем обратно в строку
    new_content = '\n'.join(new_lines)
    
    # Сохраняем изменённый файл
    app_file.write_text(new_content)
    print(f"\n{Colors.GREEN}✓{Colors.NC} app.ts успешно обновлён\n")
    
    # Выводим что было добавлено
    print(f"{Colors.BLUE}[4]{Colors.NC} Резюме изменений:")
    if imports_added:
        print(f"  {Colors.GREEN}✓{Colors.NC} Импорты: authRoutes, projectRoutes")
    if body_parser_updated:
        print(f"  {Colors.GREEN}✓{Colors.NC} Body parser с лимитом 10mb")
    if routes_added:
        print(f"  {Colors.GREEN}✓{Colors.NC} Роуты: /api/auth, /api/projects, /api/storage/stats")
    
    print(f"\n{Colors.BLUE}{'=' * 70}{Colors.NC}")
    print(f"{Colors.GREEN}✅ Обновление завершено!{Colors.NC}")
    print(f"{Colors.BLUE}{'=' * 70}{Colors.NC}\n")
    
    print(f"{Colors.YELLOW}Следующие шаги:{Colors.NC}")
    print("  1. npm run build")
    print("  2. systemctl restart kiosk-license-server")
    print("")
    print(f"{Colors.BLUE}Backup:{Colors.NC} {backup_file}\n")
    
    return True

if __name__ == "__main__":
    try:
        success = update_app_ts()
        sys.exit(0 if success else 1)
    except Exception as e:
        print_error(f"Ошибка: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
