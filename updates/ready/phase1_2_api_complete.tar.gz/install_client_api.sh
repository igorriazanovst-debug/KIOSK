#!/bin/bash
################################################################################
# Полная автоматическая установка Client API
# Фаза 1.2 - API Эндпоинты
################################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Автоматическая установка Client API v1.0                        ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

SERVER_PATH="/opt/kiosk/kiosk-content-platform/packages/server"
TEMP_DIR="/tmp"

# Проверка что мы в правильной директории
if [ ! -d "$SERVER_PATH" ]; then
    echo -e "${RED}❌ Директория server не найдена: $SERVER_PATH${NC}"
    exit 1
fi

echo -e "${GREEN}✓${NC} Server path: $SERVER_PATH"
echo ""

# Проверка что файлы извлечены
echo -e "${BLUE}[1/8] Проверка файлов...${NC}"

required_files=(
    "UserProfileService.ts"
    "ProjectService.ts"
    "FileService.ts"
    "authClient.ts"
    "storageLimit.ts"
    "AuthController.ts"
    "ProjectController.ts"
    "FileController.ts"
    "auth.routes.ts"
    "project.routes.ts"
)

all_files_exist=true
for file in "${required_files[@]}"; do
    if [ ! -f "$TEMP_DIR/$file" ]; then
        echo -e "${RED}✗${NC} Не найден: $file"
        all_files_exist=false
    fi
done

if [ "$all_files_exist" = false ]; then
    echo ""
    echo -e "${RED}❌ Не все файлы найдены в $TEMP_DIR${NC}"
    echo -e "${YELLOW}Извлеките архив phase1_2_api_endpoints.tar.gz в /tmp/${NC}"
    exit 1
fi

echo -e "${GREEN}✓${NC} Все файлы найдены"
echo ""

# Установка зависимостей
echo -e "${BLUE}[2/8] Установка зависимостей...${NC}"
cd "$SERVER_PATH"

if npm list multer &>/dev/null; then
    echo -e "${GREEN}✓${NC} multer уже установлен"
else
    echo -e "${YELLOW}Установка multer...${NC}"
    npm install multer @types/multer --save
    echo -e "${GREEN}✓${NC} multer установлен"
fi
echo ""

# Копирование файлов
echo -e "${BLUE}[3/8] Копирование файлов...${NC}"

# Services
cp "$TEMP_DIR/UserProfileService.ts" "$SERVER_PATH/src/services/"
cp "$TEMP_DIR/ProjectService.ts" "$SERVER_PATH/src/services/"
cp "$TEMP_DIR/FileService.ts" "$SERVER_PATH/src/services/"
echo -e "${GREEN}  ✓${NC} Services скопированы"

# Middleware
cp "$TEMP_DIR/authClient.ts" "$SERVER_PATH/src/middleware/"
cp "$TEMP_DIR/storageLimit.ts" "$SERVER_PATH/src/middleware/"
echo -e "${GREEN}  ✓${NC} Middleware скопированы"

# Controllers
cp "$TEMP_DIR/AuthController.ts" "$SERVER_PATH/src/controllers/"
cp "$TEMP_DIR/ProjectController.ts" "$SERVER_PATH/src/controllers/"
cp "$TEMP_DIR/FileController.ts" "$SERVER_PATH/src/controllers/"
echo -e "${GREEN}  ✓${NC} Controllers скопированы"

# Routes
cp "$TEMP_DIR/auth.routes.ts" "$SERVER_PATH/src/routes/"
cp "$TEMP_DIR/project.routes.ts" "$SERVER_PATH/src/routes/"
echo -e "${GREEN}  ✓${NC} Routes скопированы"

echo ""

# Создание директории для загрузок
echo -e "${BLUE}[4/8] Создание директории uploads...${NC}"
mkdir -p /opt/kiosk/uploads/projects
chmod -R 755 /opt/kiosk/uploads
echo -e "${GREEN}✓${NC} /opt/kiosk/uploads/projects создана"
echo ""

# Обновление .env
echo -e "${BLUE}[5/8] Обновление .env...${NC}"
if grep -q "UPLOAD_DIR" "$SERVER_PATH/.env"; then
    echo -e "${YELLOW}⚠${NC}  UPLOAD_DIR уже существует в .env"
else
    echo "" >> "$SERVER_PATH/.env"
    echo "# Upload directory for project files" >> "$SERVER_PATH/.env"
    echo "UPLOAD_DIR=/opt/kiosk/uploads" >> "$SERVER_PATH/.env"
    echo -e "${GREEN}✓${NC} UPLOAD_DIR добавлен в .env"
fi
echo ""

# Обновление app.ts
echo -e "${BLUE}[6/8] Обновление app.ts...${NC}"

if [ -f "$TEMP_DIR/update_app_ts.py" ]; then
    python3 "$TEMP_DIR/update_app_ts.py"
else
    echo -e "${RED}❌ update_app_ts.py не найден${NC}"
    echo -e "${YELLOW}Пропускаем автоматическое обновление app.ts${NC}"
    echo -e "${YELLOW}Обновите app.ts вручную согласно инструкции${NC}"
fi
echo ""

# Компиляция
echo -e "${BLUE}[7/8] Компиляция TypeScript...${NC}"
cd "$SERVER_PATH"

if npm run build; then
    echo ""
    echo -e "${GREEN}✓${NC} Компиляция успешна"
else
    echo ""
    echo -e "${RED}❌ Ошибка компиляции${NC}"
    echo -e "${YELLOW}Проверьте ошибки выше${NC}"
    exit 1
fi
echo ""

# Перезапуск сервера
echo -e "${BLUE}[8/8] Перезапуск License Server...${NC}"
systemctl restart kiosk-license-server

# Ждём 3 секунды для запуска
sleep 3

if systemctl is-active --quiet kiosk-license-server; then
    echo -e "${GREEN}✓${NC} License Server запущен"
else
    echo -e "${RED}❌ License Server не запустился${NC}"
    echo -e "${YELLOW}Проверьте логи: journalctl -u kiosk-license-server -n 50${NC}"
    exit 1
fi
echo ""

# Финальная проверка
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ Установка завершена успешно!${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${YELLOW}Проверка API:${NC}"
echo ""

# Health check
echo -e "${BLUE}Health check:${NC}"
curl -s http://localhost:3001/health | jq -r '.status' 2>/dev/null && \
    echo -e "${GREEN}✓${NC} Health check OK" || \
    echo -e "${RED}✗${NC} Health check failed"
echo ""

# Тест авторизации
echo -e "${BLUE}Тест авторизации (лицензия BASIC):${NC}"
RESPONSE=$(curl -s -X POST http://localhost:3001/api/auth/license \
  -H "Content-Type: application/json" \
  -d '{"licenseKey":"EWZA-E5LJ-Z558-9LUQ"}')

if echo "$RESPONSE" | jq -e '.success' &>/dev/null; then
    TOKEN=$(echo "$RESPONSE" | jq -r '.token')
    echo -e "${GREEN}✓${NC} Авторизация успешна"
    echo -e "${GREEN}✓${NC} Токен получен"
    
    # Тест создания проекта
    echo ""
    echo -e "${BLUE}Тест создания проекта:${NC}"
    PROJECT_RESPONSE=$(curl -s -X POST http://localhost:3001/api/projects \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d '{"name":"Test Project","projectData":{}}')
    
    if echo "$PROJECT_RESPONSE" | jq -e '.success' &>/dev/null; then
        echo -e "${GREEN}✓${NC} Проект создан успешно"
        PROJECT_ID=$(echo "$PROJECT_RESPONSE" | jq -r '.project.id')
        echo -e "  Project ID: $PROJECT_ID"
    else
        echo -e "${RED}✗${NC} Ошибка создания проекта"
    fi
else
    echo -e "${RED}✗${NC} Ошибка авторизации"
fi

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${YELLOW}Доступные API эндпоинты:${NC}"
echo ""
echo "  Аутентификация:"
echo "    POST /api/auth/license"
echo "    POST /api/auth/refresh"
echo "    GET  /api/auth/verify"
echo ""
echo "  Проекты:"
echo "    GET    /api/projects"
echo "    POST   /api/projects"
echo "    GET    /api/projects/:id"
echo "    PUT    /api/projects/:id"
echo "    DELETE /api/projects/:id"
echo ""
echo "  Файлы:"
echo "    GET    /api/projects/:id/files"
echo "    POST   /api/projects/:id/files"
echo "    GET    /api/projects/:id/files/:fid"
echo "    DELETE /api/projects/:id/files/:fid"
echo ""
echo "  Хранилище:"
echo "    GET /api/storage/stats"
echo ""

echo -e "${BLUE}Логи сервера:${NC}"
echo "  journalctl -u kiosk-license-server -f"
echo ""
