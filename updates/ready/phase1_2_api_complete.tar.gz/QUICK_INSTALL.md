# 🚀 Быстрая установка Client API

**Архив:** `phase1_2_api_complete.tar.gz` (16 KB)

---

## ⚡ Автоматическая установка (3 команды)

```bash
# 1. Загрузить архив на сервер
scp phase1_2_api_complete.tar.gz root@31.192.110.121:/tmp/

# 2. На сервере: распаковать
ssh root@31.192.110.121
cd /tmp && tar -xzf phase1_2_api_complete.tar.gz

# 3. Запустить автоматическую установку
chmod +x install_client_api.sh
./install_client_api.sh
```

**Всё! 🎉**

Скрипт автоматически:
- ✅ Установит зависимости (multer)
- ✅ Скопирует все файлы в нужные директории
- ✅ Создаст директорию для загрузок
- ✅ Обновит .env
- ✅ Обновит app.ts (добавит роуты)
- ✅ Скомпилирует TypeScript
- ✅ Перезапустит License Server
- ✅ Протестирует API

---

## 🔍 Что делает скрипт install_client_api.sh

```
[1/8] Проверка файлов          - все 10 файлов на месте
[2/8] Установка зависимостей   - npm install multer
[3/8] Копирование файлов        - в src/services, controllers, routes
[4/8] Создание uploads/         - /opt/kiosk/uploads/projects
[5/8] Обновление .env           - UPLOAD_DIR=/opt/kiosk/uploads
[6/8] Обновление app.ts         - добавление роутов (Python скрипт)
[7/8] Компиляция                - npm run build
[8/8] Перезапуск сервера        - systemctl restart
```

---

## 📋 Что входит в архив

```
phase1_2_api_complete.tar.gz
├── Services/ (3 файла)
│   ├── UserProfileService.ts
│   ├── ProjectService.ts
│   └── FileService.ts
├── Middleware/ (2 файла)
│   ├── authClient.ts
│   └── storageLimit.ts
├── Controllers/ (3 файла)
│   ├── AuthController.ts
│   ├── ProjectController.ts
│   └── FileController.ts
├── Routes/ (2 файла)
│   ├── auth.routes.ts
│   └── project.routes.ts
├── Scripts/
│   ├── update_app_ts.py          ← Обновление app.ts
│   └── install_client_api.sh     ← Автоустановка
└── PHASE1_2_INSTRUCTION.md       ← Полная инструкция
```

---

## ✅ После установки

Скрипт автоматически протестирует API:

```
✓ Health check OK
✓ Авторизация успешна  
✓ Токен получен
✓ Проект создан успешно
```

Если всё ок - увидишь список доступных эндпоинтов.

---

## 🐛 Если что-то пошло не так

### Скрипт остановился на компиляции

```bash
# Проверь логи компиляции
cd /opt/kiosk/kiosk-content-platform/packages/server
npm run build
```

### License Server не запустился

```bash
# Проверь логи
journalctl -u kiosk-license-server -n 100 --no-pager
```

### Роуты не добавились в app.ts

```bash
# Обнови вручную
cd /tmp
python3 update_app_ts.py
```

---

## 🧪 Ручное тестирование

После установки можешь протестировать вручную:

```bash
# 1. Авторизация
curl -X POST http://localhost:3001/api/auth/license \
  -H "Content-Type: application/json" \
  -d '{"licenseKey":"EWZA-E5LJ-Z558-9LUQ"}' | jq .

# Сохрани токен
TOKEN="<your-token>"

# 2. Создать проект
curl -X POST http://localhost:3001/api/projects \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","projectData":{}}' | jq .

# 3. Список проектов
curl http://localhost:3001/api/projects \
  -H "Authorization: Bearer $TOKEN" | jq .
```

---

## 📖 Полная документация

См. файл `PHASE1_2_INSTRUCTION.md` в архиве.

---

**Вопросы?** Загрузи это резюме в новый чат! 🚀
