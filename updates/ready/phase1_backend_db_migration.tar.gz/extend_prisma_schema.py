#!/usr/bin/env python3
"""
Скрипт для расширения Prisma schema - добавление таблиц для Online Editor
Фаза 1: Backend API
"""

SCHEMA_EXTENSION = """
// ============================================================================
// ONLINE EDITOR EXTENSION - Projects and Files
// Added: 2026-02-02
// ============================================================================

// Профили пользователей (настройки)
model UserProfile {
  id                    String   @id @default(uuid())
  userId                String   @unique
  
  // Настройки редактора
  autoSaveInterval      Int      @default(180) // секунды (3 минуты по умолчанию)
  theme                 String   @default("dark")
  language              String   @default("en")
  
  // Статистика
  totalProjects         Int      @default(0)
  totalStorageUsed      BigInt   @default(0) // байты
  
  user                  User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  createdAt             DateTime @default(now())
  updatedAt             DateTime @updatedAt
  
  @@map("user_profiles")
}

// Проекты (киоск-контент)
model Project {
  id                    String         @id @default(uuid())
  name                  String
  description           String?
  
  // Владение
  licenseId             String
  organizationId        String
  createdByUserId       String?
  
  // Контент проекта (JSON)
  projectData           Json           // Полный JSON проекта (структура из Editor)
  
  // Настройки холста
  canvasWidth           Int            @default(1920)
  canvasHeight          Int            @default(1080)
  canvasBackground      String         @default("#1a1a1a")
  
  // Метаданные
  version               Int            @default(1)
  thumbnail             String?        // URL или base64 превью
  tags                  String[]       // Теги для поиска
  
  // Статистика
  totalFiles            Int            @default(0)
  totalStorageUsed      BigInt         @default(0) // байты
  viewCount             Int            @default(0)
  
  // Публикация
  isPublished           Boolean        @default(false)
  publishedAt           DateTime?
  
  // Связи
  license               License        @relation(fields: [licenseId], references: [id], onDelete: Cascade)
  organization          Organization   @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  createdByUser         User?          @relation(fields: [createdByUserId], references: [id], onDelete: SetNull)
  files                 ProjectFile[]
  
  createdAt             DateTime       @default(now())
  updatedAt             DateTime       @updatedAt
  lastEditedAt          DateTime       @default(now())
  
  @@index([licenseId])
  @@index([organizationId])
  @@index([createdByUserId])
  @@index([name])
  @@index([isPublished])
  @@index([createdAt])
  @@map("projects")
}

// Файлы проектов (медиа-ресурсы)
model ProjectFile {
  id                    String       @id @default(uuid())
  projectId             String
  
  // Информация о файле
  fileName              String
  fileType              FileType
  mimeType              String
  fileSize              BigInt       // байты
  
  // Хранение
  storagePath           String       // Путь на диске: /uploads/projects/{projectId}/{fileId}.ext
  url                   String       // URL для доступа: /api/projects/{projectId}/files/{fileId}
  
  // Метаданные
  width                 Int?         // для изображений
  height                Int?         // для изображений
  duration              Int?         // для видео (секунды)
  thumbnail             String?      // превью для видео
  
  // Использование
  usageCount            Int          @default(0) // сколько раз используется в виджетах
  
  // Связи
  project               Project      @relation(fields: [projectId], references: [id], onDelete: Cascade)
  
  createdAt             DateTime     @default(now())
  updatedAt             DateTime     @updatedAt
  
  @@index([projectId])
  @@index([fileType])
  @@index([createdAt])
  @@map("project_files")
}

enum FileType {
  IMAGE
  VIDEO
  AUDIO
  DOCUMENT
  OTHER
}

// ============================================================================
// EXTENSIONS TO EXISTING MODELS
// ============================================================================

// User model extension (добавить в существующую модель User):
// userProfile  UserProfile?
// projects     Project[]

// License model extension (добавить в существующую модель License):
// projects     Project[]
// storageLimit BigInt       @default(524288000) // 500 MB для BASIC
// Limits by plan:
// BASIC: 500 MB (524288000 bytes)
// PRO:   1500 MB (1572864000 bytes)
// MAX:   3000 MB (3145728000 bytes)

// Organization model extension (добавить в существующую модель Organization):
// projects     Project[]
"""

def add_schema_extensions():
    """Добавляет новые модели в schema.prisma"""
    
    print("=" * 80)
    print("📋 Расширение Prisma Schema для Online Editor")
    print("=" * 80)
    print()
    
    print("📝 Содержимое для добавления в schema.prisma:")
    print()
    print(SCHEMA_EXTENSION)
    print()
    
    print("=" * 80)
    print("✅ ИНСТРУКЦИИ:")
    print("=" * 80)
    print()
    print("1. Откройте файл: packages/server/prisma/schema.prisma")
    print()
    print("2. Добавьте новые модели в КОНЕЦ файла (перед закрывающей скобкой)")
    print()
    print("3. Обновите существующие модели:")
    print()
    print("   В модель User добавьте:")
    print("   ---")
    print("   userProfile  UserProfile?")
    print("   projects     Project[]")
    print("   ---")
    print()
    print("   В модель License добавьте:")
    print("   ---")
    print("   projects     Project[]")
    print("   storageLimit BigInt       @default(524288000) // 500 MB")
    print("   ---")
    print()
    print("   В модель Organization добавьте:")
    print("   ---")
    print("   projects     Project[]")
    print("   ---")
    print()
    print("4. Создайте миграцию:")
    print("   ---")
    print("   cd packages/server")
    print("   npx prisma migrate dev --name add_online_editor_tables")
    print("   ---")
    print()
    print("5. Примените миграцию:")
    print("   ---")
    print("   npx prisma migrate deploy")
    print("   ---")
    print()
    print("6. Регенерируйте Prisma Client:")
    print("   ---")
    print("   npx prisma generate")
    print("   ---")
    print()
    print("=" * 80)
    print()
    
    # Сохраняем в файл для удобства
    output_file = "/home/claude/schema_extension.prisma"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(SCHEMA_EXTENSION)
    
    print(f"💾 Расширение сохранено в: {output_file}")
    print()
    print("Вы можете скопировать содержимое этого файла в schema.prisma")
    print()

if __name__ == "__main__":
    add_schema_extensions()
