-- Migration script: Update storage limits for existing licenses
-- Filename: packages/server/prisma/migrations/[timestamp]_add_online_editor_tables/migration.sql
-- Run after: npx prisma migrate dev --name add_online_editor_tables

-- Update storage limits based on plan
UPDATE licenses
SET "storageLimit" = CASE
  WHEN plan = 'BASIC' THEN 524288000    -- 500 MB
  WHEN plan = 'PRO'   THEN 1572864000   -- 1500 MB  
  WHEN plan = 'MAX'   THEN 3145728000   -- 3000 MB
  ELSE 524288000                         -- Default to BASIC
END
WHERE "storageLimit" = 524288000;       -- Only update records with default value

-- Verify results
SELECT 
  plan,
  COUNT(*) as count,
  "storageLimit",
  ROUND("storageLimit" / 1048576.0, 2) as storage_mb
FROM licenses
GROUP BY plan, "storageLimit"
ORDER BY plan;
