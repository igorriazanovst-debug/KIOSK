/**
 * App Component - ВЕРСИЯ 3.0
 * С роутингом и защитой маршрутов
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import EditorPage from './pages/EditorPage';
import ProtectedRoute from './components/ProtectedRoute';
import ErrorBoundary from './components/ErrorBoundary';
import { apiClient } from './services/api-client';
import { logger } from './utils/logger';

function App() {
  // Логировать загрузку приложения
  React.useEffect(() => {
    logger.info('Application started', {
      isAuthenticated: apiClient.isAuthenticated()
    });
  }, []);

  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          {/* Редирект с главной страницы */}
          <Route 
            path="/" 
            element={
              apiClient.isAuthenticated() 
                ? <Navigate to="/editor" replace /> 
                : <Navigate to="/login" replace />
            } 
          />

          {/* Страница авторизации */}
          <Route path="/login" element={<LoginPage />} />

          {/* Защищённая страница редактора */}
          <Route
            path="/editor"
            element={
              <ProtectedRoute>
                <EditorPage />
              </ProtectedRoute>
            }
          />

          {/* 404 - редирект на главную */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

export default App;
