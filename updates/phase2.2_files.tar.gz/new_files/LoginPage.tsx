/**
 * LoginPage Component
 * Страница авторизации по лицензионному ключу
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Key, AlertCircle, Loader2 } from 'lucide-react';
import { apiClient } from '../services/api-client';
import { logger } from '../utils/logger';
import './LoginPage.css';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const [licenseKey, setLicenseKey] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Проверить авторизацию при загрузке
  useEffect(() => {
    if (apiClient.isAuthenticated()) {
      logger.info('User already authenticated - redirecting to editor');
      navigate('/editor', { replace: true });
    }
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!licenseKey.trim()) {
      setError('Введите лицензионный ключ');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      logger.info('Attempting login');
      const response = await apiClient.loginWithLicense(licenseKey.trim());

      if (response.success && response.token) {
        logger.info('Login successful - redirecting to editor');
        navigate('/editor', { replace: true });
      } else {
        setError('Неверный лицензионный ключ');
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Ошибка авторизации';
      logger.error('Login failed', { error: message });
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const formatLicenseKey = (value: string): string => {
    // Удалить все символы кроме букв и цифр
    const cleaned = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    
    // Разбить на группы по 4 символа
    const groups = cleaned.match(/.{1,4}/g) || [];
    
    // Объединить через дефис
    return groups.join('-').substring(0, 19); // XXXX-XXXX-XXXX-XXXX
  };

  const handleKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatLicenseKey(e.target.value);
    setLicenseKey(formatted);
    setError(null);
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-header">
          <div className="login-icon">
            <Key size={32} />
          </div>
          <h1>Kiosk Content Editor</h1>
          <p>Введите лицензионный ключ для входа</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label htmlFor="licenseKey">Лицензионный ключ</label>
            <input
              id="licenseKey"
              type="text"
              value={licenseKey}
              onChange={handleKeyChange}
              placeholder="XXXX-XXXX-XXXX-XXXX"
              disabled={loading}
              autoFocus
              autoComplete="off"
              maxLength={19}
            />
          </div>

          {error && (
            <div className="error-message">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          <button 
            type="submit" 
            className="login-button"
            disabled={loading || !licenseKey.trim()}
          >
            {loading ? (
              <>
                <Loader2 size={18} className="spinner" />
                <span>Проверка...</span>
              </>
            ) : (
              <>
                <Key size={18} />
                <span>Войти</span>
              </>
            )}
          </button>
        </form>

        <div className="login-footer">
          <p className="help-text">
            Нет лицензионного ключа? Свяжитесь с администратором.
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
