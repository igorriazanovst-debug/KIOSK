# 🔐 Phase 2.2: Безопасная авторизация и роутинг

**Дата:** 05.02.2026  
**Версия:** 2.2.0  
**Статус:** Готово к установке

---

## 📋 Что изменилось

### 🔒 Безопасность
- ✅ Токен перемещён из `localStorage` в `sessionStorage`
- ✅ Токен живёт только до закрытия браузера
- ✅ Автоматический logout после 30 минут неактивности
- ✅ Автосохранение проекта перед logout

### 🌐 Роутинг
- ✅ Две отдельные страницы: `/login` и `/editor`
- ✅ Защита маршрутов от неавторизованных пользователей
- ✅ Автоматический редирект на нужную страницу

### 🎨 UI/UX
- ✅ Отдельная красивая страница авторизации
- ✅ LoginDialog удалён
- ✅ Индикатор сохранения при выходе по таймауту

---

## 📦 Новые файлы

### Утилиты
```
src/utils/
└── logger.ts                    # Журналирование событий и ошибок
```

### Хуки
```
src/hooks/
└── useActivityTimeout.ts        # Мониторинг активности пользователя
```

### Компоненты
```
src/components/
└── ProtectedRoute.tsx           # Защита маршрутов
```

### Страницы
```
src/pages/
├── LoginPage.tsx                # Страница авторизации
├── LoginPage.css                # Стили страницы авторизации
├── EditorPage.tsx               # Страница редактора
└── EditorPage.css               # Стили страницы редактора
```

---

## 🔧 Изменённые файлы

### 1. package.json
**Добавлена зависимость:**
```json
"react-router-dom": "^6.20.0"
```

### 2. src/App.tsx
**Было:**
```tsx
function App() {
  return (
    <ErrorBoundary>
      <Editor />
    </ErrorBoundary>
  );
}
```

**Стало:**
```tsx
function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/editor" element={<ProtectedRoute><EditorPage /></ProtectedRoute>} />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
```

### 3. src/services/api-client.ts
**Изменения:**
- `localStorage` → `sessionStorage`
- Удалена логика таймера неактивности (перенесена в хук)
- Добавлен метод `getOrganizationData()`
- Улучшено логирование через `logger`

### 4. src/components/Toolbar.tsx
**Изменения:**
- Удалён `LoginDialog`
- Добавлена кнопка выхода
- Убрана логика управления `showLoginDialog`

---

## 🗑️ Удалённые файлы

```
src/components/LoginDialog.tsx       → .disabled
src/components/LoginDialog.css       → .disabled
```

---

## 🚀 Инструкция по установке

### Способ 1: Автоматическая установка (рекомендуется)

```bash
# 1. Скопировать файлы на сервер
scp -r /path/to/new_files root@31.192.110.121:/tmp/kiosk_phase2.2/

# 2. Подключиться к серверу
ssh root@31.192.110.121

# 3. Скопировать новые файлы в проект
cd /tmp/kiosk_phase2.2

# Утилиты
cp logger.ts /opt/kiosk/kiosk-content-platform/packages/editor-web/src/utils/

# Хуки
cp useActivityTimeout.ts /opt/kiosk/kiosk-content-platform/packages/editor-web/src/hooks/

# Компоненты
cp ProtectedRoute.tsx /opt/kiosk/kiosk-content-platform/packages/editor-web/src/components/

# Страницы
cp LoginPage.tsx LoginPage.css EditorPage.tsx EditorPage.css \
   /opt/kiosk/kiosk-content-platform/packages/editor-web/src/pages/

# Основные файлы
cp package.json /opt/kiosk/kiosk-content-platform/packages/editor-web/
cp App.tsx /opt/kiosk/kiosk-content-platform/packages/editor-web/src/
cp api-client.ts /opt/kiosk/kiosk-content-platform/packages/editor-web/src/services/
cp Toolbar.tsx /opt/kiosk/kiosk-content-platform/packages/editor-web/src/components/

# 4. Запустить скрипт установки
chmod +x install_phase2.2.sh
./install_phase2.2.sh
```

### Способ 2: Ручная установка

#### Шаг 1: Backup
```bash
cd /opt/kiosk/kiosk-content-platform/packages
cp -r editor-web editor-web.backup.$(date +%Y%m%d_%H%M%S)
```

#### Шаг 2: Установить зависимости
```bash
cd /opt/kiosk/kiosk-content-platform/packages/editor-web
npm install react-router-dom@^6.20.0 --save
```

#### Шаг 3: Создать структуру
```bash
mkdir -p src/pages
mkdir -p src/hooks
mkdir -p src/utils
```

#### Шаг 4: Скопировать файлы
(Используйте команды из Способа 1, шаг 3)

#### Шаг 5: Отключить старые файлы
```bash
cd /opt/kiosk/kiosk-content-platform/packages/editor-web/src/components
mv LoginDialog.tsx LoginDialog.tsx.disabled
mv LoginDialog.css LoginDialog.css.disabled
```

#### Шаг 6: Build и Deploy
```bash
cd /opt/kiosk/kiosk-content-platform/packages/editor-web
npm run build
rm -rf /opt/kiosk/editor-web/*
cp -r dist/* /opt/kiosk/editor-web/
systemctl reload nginx
```

---

## 🧪 Тестирование

### Тест 1: Авторизация
1. Откройте http://31.192.110.121:8080
2. **Ожидается:** Страница авторизации с формой ввода ключа
3. Введите ключ: `3VBN-8ZQ9-1MKO-AK0R`
4. Нажмите "Войти"
5. **Ожидается:** Редирект на `/editor`, появляется редактор

### Тест 2: Сохранение сессии (F5)
1. Авторизуйтесь в системе
2. Нажмите F5 (обновить страницу)
3. **Ожидается:** Редактор остаётся открытым, повторная авторизация НЕ требуется

### Тест 3: Закрытие браузера
1. Авторизуйтесь в системе
2. Закройте браузер полностью
3. Откройте браузер снова
4. Перейдите на http://31.192.110.121:8080
5. **Ожидается:** Страница авторизации, токен удалён

### Тест 4: Таймаут неактивности
1. Авторизуйтесь в системе
2. Создайте несколько виджетов в проекте
3. Не трогайте мышь/клавиатуру 30 минут
4. **Ожидается:** 
   - Проект автоматически сохранится
   - Произойдёт автоматический выход
   - Редирект на `/login`

### Тест 5: Попытка прямого доступа
1. НЕ авторизуясь, попробуйте открыть http://31.192.110.121:8080/editor
2. **Ожидается:** Автоматический редирект на `/login`

### Тест 6: Ручной выход
1. Авторизуйтесь в системе
2. Нажмите кнопку "Выйти" (иконка LogOut)
3. Подтвердите выход
4. **Ожидается:** Редирект на `/login`

---

## 📊 Проверка в DevTools

### Проверка sessionStorage
```javascript
// В консоли браузера (F12)
JSON.parse(sessionStorage.getItem('kiosk_auth_token'))

// Ожидается:
{
  token: "eyJ...",
  organizationName: "Demo Organization",
  plan: "PRO",
  savedAt: "2026-02-05T..."
}
```

### Проверка логов
```javascript
// В консоли браузера
// Должны видеть логи:
// [INFO] Application started
// [INFO] Attempting login with license key
// [INFO] Login successful
// [INFO] Activity timeout monitoring started
```

---

## 🐛 Возможные проблемы

### Проблема 1: Build ошибки
**Симптом:** `npm run build` завершается с ошибками

**Решение:**
```bash
# Проверить TypeScript ошибки
cd /opt/kiosk/kiosk-content-platform/packages/editor-web
npx tsc --noEmit

# Если есть ошибки в импортах
npm install --force
```

### Проблема 2: 404 на /login или /editor
**Симптом:** При переходе на `/login` или `/editor` показывается 404

**Решение:** Обновить конфигурацию Nginx для SPA:
```nginx
location / {
    try_files $uri $uri/ /index.html;
}
```

### Проблема 3: Токен не сохраняется
**Симптом:** После F5 требуется повторный вход

**Решение:** Проверить что используется `sessionStorage`:
```javascript
// В api-client.ts должно быть:
sessionStorage.setItem('kiosk_auth_token', ...)
// А НЕ:
localStorage.setItem('kiosk_auth_token', ...)
```

### Проблема 4: Таймаут не срабатывает
**Симптом:** Через 30 минут выход не происходит

**Решение:** Проверить хук в EditorPage:
```javascript
// Убедиться что useActivityTimeout вызывается:
useActivityTimeout({
  timeout: 30 * 60 * 1000,
  onTimeout: handleInactivityTimeout
});
```

---

## 📝 Отличия от Phase 2.1

| Аспект | Phase 2.1 | Phase 2.2 |
|--------|-----------|-----------|
| **Хранение токена** | localStorage (постоянно) | sessionStorage (до закрытия браузера) |
| **Структура страниц** | Одна страница с LoginDialog | Две отдельные страницы /login и /editor |
| **Таймаут** | Нет | 30 минут с автосохранением |
| **Защита маршрутов** | Нет | ProtectedRoute компонент |
| **Роутинг** | Нет | react-router-dom |
| **Логирование** | console.log | Централизованный logger |

---

## 🎯 Следующие шаги (Phase 2.3)

После успешной установки Phase 2.2:

1. **ProjectsList компонент** - список проектов организации
2. **Восстановление Image виджета** - загрузка изображений
3. **Toast notifications** - уведомления об успешных действиях
4. **Loading indicators** - индикаторы загрузки

---

**Версия:** 2.2.0  
**Дата:** 05.02.2026  
**Автор:** Kiosk Development Team  
**Статус:** ✅ Готово к установке
