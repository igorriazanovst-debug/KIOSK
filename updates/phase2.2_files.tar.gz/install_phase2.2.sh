#!/bin/bash
################################################################################
# Скрипт установки Phase 2.2: Безопасная авторизация и роутинг
# 
# Что делает:
# 1. Создаёт backup существующих файлов
# 2. Устанавливает react-router-dom
# 3. Копирует новые файлы
# 4. Обновляет существующие файлы
# 5. Выполняет build и deploy
################################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Phase 2.2: Безопасная авторизация и роутинг                      ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

EDITOR_PATH="/opt/kiosk/kiosk-content-platform/packages/editor-web"
BACKUP_PATH="${EDITOR_PATH}.backup.$(date +%Y%m%d_%H%M%S)"
TEMP_FILES="/tmp/kiosk_phase2.2"

# ============================================================================
# ШАГ 1: Проверка существования директорий
# ============================================================================

echo -e "${YELLOW}[1/8] Проверка директорий...${NC}"

if [ ! -d "$EDITOR_PATH" ]; then
    echo -e "${RED}❌ Директория editor-web не найдена: $EDITOR_PATH${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Директория найдена${NC}"
echo ""

# ============================================================================
# ШАГ 2: Создание backup
# ============================================================================

echo -e "${YELLOW}[2/8] Создание backup...${NC}"

cp -r "$EDITOR_PATH" "$BACKUP_PATH"
echo -e "${GREEN}✅ Backup создан: $BACKUP_PATH${NC}"
echo ""

# ============================================================================
# ШАГ 3: Установка зависимостей
# ============================================================================

echo -e "${YELLOW}[3/8] Установка react-router-dom...${NC}"

cd "$EDITOR_PATH"

# Проверить наличие react-router-dom
if grep -q '"react-router-dom"' package.json; then
    echo -e "${GREEN}✅ react-router-dom уже установлен${NC}"
else
    echo "   Добавляем react-router-dom в package.json..."
    npm install react-router-dom@^6.20.0 --save
    echo -e "${GREEN}✅ react-router-dom установлен${NC}"
fi

echo ""

# ============================================================================
# ШАГ 4: Создание новых директорий
# ============================================================================

echo -e "${YELLOW}[4/8] Создание структуры директорий...${NC}"

mkdir -p "$EDITOR_PATH/src/pages"
mkdir -p "$EDITOR_PATH/src/hooks"
mkdir -p "$EDITOR_PATH/src/utils"

echo -e "${GREEN}✅ Директории созданы${NC}"
echo ""

# ============================================================================
# ШАГ 5: Копирование новых файлов
# ============================================================================

echo -e "${YELLOW}[5/8] Копирование новых файлов...${NC}"

# Эти файлы будут скопированы вручную или через другой скрипт
echo "   Файлы для копирования:"
echo "   - src/utils/logger.ts"
echo "   - src/hooks/useActivityTimeout.ts"
echo "   - src/components/ProtectedRoute.tsx"
echo "   - src/pages/LoginPage.tsx"
echo "   - src/pages/LoginPage.css"
echo "   - src/pages/EditorPage.tsx"
echo "   - src/pages/EditorPage.css"
echo ""
echo -e "${YELLOW}⚠️  Файлы нужно скопировать вручную!${NC}"
echo ""

read -p "Файлы скопированы? (y/n): " FILES_COPIED

if [ "$FILES_COPIED" != "y" ]; then
    echo -e "${RED}Отменено пользователем${NC}"
    exit 1
fi

# ============================================================================
# ШАГ 6: Обновление существующих файлов
# ============================================================================

echo -e "${YELLOW}[6/8] Обновление существующих файлов...${NC}"

# Список файлов для обновления
echo "   Файлы для обновления:"
echo "   - src/App.tsx"
echo "   - src/services/api-client.ts"
echo "   - src/components/Toolbar.tsx"
echo ""
echo -e "${YELLOW}⚠️  Файлы нужно обновить вручную!${NC}"
echo ""

read -p "Файлы обновлены? (y/n): " FILES_UPDATED

if [ "$FILES_UPDATED" != "y" ]; then
    echo -e "${RED}Отменено пользователем${NC}"
    exit 1
fi

# ============================================================================
# ШАГ 7: Удаление устаревших файлов
# ============================================================================

echo -e "${YELLOW}[7/8] Удаление устаревших компонентов...${NC}"

# LoginDialog больше не нужен
if [ -f "$EDITOR_PATH/src/components/LoginDialog.tsx" ]; then
    mv "$EDITOR_PATH/src/components/LoginDialog.tsx" \
       "$EDITOR_PATH/src/components/LoginDialog.tsx.disabled"
    echo "   ✓ LoginDialog.tsx → disabled"
fi

if [ -f "$EDITOR_PATH/src/components/LoginDialog.css" ]; then
    mv "$EDITOR_PATH/src/components/LoginDialog.css" \
       "$EDITOR_PATH/src/components/LoginDialog.css.disabled"
    echo "   ✓ LoginDialog.css → disabled"
fi

echo -e "${GREEN}✅ Устаревшие файлы отключены${NC}"
echo ""

# ============================================================================
# ШАГ 8: Build и Deploy
# ============================================================================

echo -e "${YELLOW}[8/8] Build и Deploy...${NC}"

cd "$EDITOR_PATH"

# Очистка предыдущего build
echo "   Очистка dist/..."
rm -rf dist

# TypeScript компиляция + Vite build
echo "   Запуск npm run build..."
if npm run build > /tmp/build_phase2.2.log 2>&1; then
    echo -e "${GREEN}   ✅ Build успешно завершён${NC}"
else
    echo -e "${RED}   ❌ Build завершился с ошибками${NC}"
    echo "   Показываем последние 30 строк лога:"
    tail -30 /tmp/build_phase2.2.log
    echo ""
    echo -e "${YELLOW}Восстанавливаем из backup...${NC}"
    rm -rf "$EDITOR_PATH"
    cp -r "$BACKUP_PATH" "$EDITOR_PATH"
    echo -e "${RED}Восстановлено из backup. Проверьте ошибки выше.${NC}"
    exit 1
fi

# Deploy в production
echo "   Копирование в /opt/kiosk/editor-web/..."
rm -rf /opt/kiosk/editor-web/*
cp -r dist/* /opt/kiosk/editor-web/

# Reload Nginx
echo "   Перезагрузка Nginx..."
systemctl reload nginx

echo -e "${GREEN}✅ Deploy завершён${NC}"
echo ""

# ============================================================================
# ИТОГО
# ============================================================================

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  ✅ PHASE 2.2 УСТАНОВЛЕНА                                          ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${GREEN}Изменения:${NC}"
echo "  ✅ Добавлен react-router-dom"
echo "  ✅ Созданы страницы /login и /editor"
echo "  ✅ Токен теперь в sessionStorage (живёт до закрытия браузера)"
echo "  ✅ Таймаут неактивности 30 минут с автосохранением"
echo "  ✅ Защита маршрутов от неавторизованных"
echo "  ✅ LoginDialog удалён, создана отдельная страница авторизации"
echo ""

echo -e "${YELLOW}📌 Backup сохранён:${NC} $BACKUP_PATH"
echo ""

echo -e "${BLUE}🧪 ТЕСТИРОВАНИЕ:${NC}"
echo "1. Откройте: http://31.192.110.121:8080"
echo "2. Вы должны увидеть страницу авторизации"
echo "3. Введите ключ: 3VBN-8ZQ9-1MKO-AK0R"
echo "4. После входа откроется редактор"
echo "5. Нажмите F5 - авторизация должна сохраниться"
echo "6. Закройте браузер и откройте снова - потребуется новый вход"
echo "7. Подождите 30 минут без активности - автоматический выход"
echo ""

echo -e "${GREEN}🎉 Готово!${NC}"
